#include<iostream>
#include<vector>
using namespace std;

class File {
    public:
        vector<string> file_rep;
};